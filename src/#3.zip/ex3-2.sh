#!/bin/bash
case "$2" in
	+)
	 echo $(expr $1 + $3);;
	-)
	 echo $(expr $1 - $3);;
	*)
	 echo "다시입력";;
esac
exit 0
