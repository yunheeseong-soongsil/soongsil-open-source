#!/bin/bash
a=`expr $2 \* $2`
bmi=`expr $1/$a`

if [1 -eq "$(echo "$bmi <18.5" |bc)"]
then
	echo "저체중입니다."
elif[$bmi -lt 23]
	echo "정상체중입니다."
else
	echo "과체중입니다."
fi
exit 0

