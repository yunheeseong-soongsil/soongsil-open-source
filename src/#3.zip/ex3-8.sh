#!/bin/sh

fname=/home/heeseong/DB.txt

touch DB.txt

echo "$1" "$2" >> DB.txt

exit 0
