#!/bin/sh
fname=/home/heeseong/file1.txt
grep $1 $fname
exit 0

